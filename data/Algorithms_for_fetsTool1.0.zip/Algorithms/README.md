# FETS-Algorithms

This repository contains the algorithms to be used in the FeTS [OpenFederatedLearning backend](https://github.com/IntelLabs/OpenFederatedLearning).
