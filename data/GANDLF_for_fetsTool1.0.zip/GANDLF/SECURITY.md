# Security Policy

## Supported Versions

Use this section to tell people about which versions of your project are
currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
|    x    | :white_check_mark: |

## Reporting a Vulnerability

Please report any vulnerabilities via [GitHub Issues](https://github.com/CBICA/GaNDLF/issues/new/choose)
