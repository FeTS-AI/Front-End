### Description

The smaller individual modules of these networks are taken from the seg_modules files as seen in the imports section.