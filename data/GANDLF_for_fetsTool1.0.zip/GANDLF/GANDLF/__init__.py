import pkg_resources

__version__ = pkg_resources.require("GANDLF")[0].version